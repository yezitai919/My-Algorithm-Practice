package real.time.scheduling;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class OSKernel {
    private final PriorityQueue<PCB> ready = new PriorityQueue<>(Comparator.comparingInt(PCB::getPriority));
    private final LinkedList<PCB> scheduling = new LinkedList<>();
    private final PriorityQueue<PCB> block = new PriorityQueue<>(Comparator.comparingInt(PCB::getArrivalTime));


    protected void creatProcess(String id,int pT,int cycle){
        PCB pcb = new  PCB(id,pT,cycle);
        ready.offer(pcb);
    }

    protected void earliestDeadlineFirst(int n){

        int currTime = 0;
        int arriTime = 0;

        while (!ready.isEmpty()||!block.isEmpty()){
            if (ready.isEmpty()&&arriTime>currTime){
                scheduling.offer(new PCB("空",(arriTime-currTime),0));
                currTime=arriTime;
            }
            if (currTime==arriTime){
                while (block.peek()!=null&&block.peek().getArrivalTime()==arriTime){
                    ready.offer(block.poll());
                }
                if (block.peek()!=null){
                    arriTime=block.peek().getArrivalTime();
                }else {
                    arriTime = ready.peek().getCompletionTimeLimit();
                }
            }
            PCB pcb = ready.poll();
            assert pcb != null;
            if (pcb.getProcessingTime()+currTime<=arriTime){
                scheduling.offer((PCB)pcb.clone());
                currTime += pcb.getProcessingTime();
                if (pcb.getCycleNum()!=n){
                    pcb.upData();
                    block.offer(pcb);
                    assert block.peek() != null;
                    arriTime = block.peek().getArrivalTime();
                }
            }else if (pcb.getProcessingTime()+currTime>arriTime){
                PCB pcb1 = (PCB) pcb.clone();
                pcb1.setProcessingTime(arriTime-currTime);
                scheduling.offer(pcb1);
                pcb.setProcessingTime(pcb.getProcessingTime()-pcb1.getProcessingTime());
                currTime = arriTime;
                ready.offer(pcb);
            }
        }
    }

    protected void viewScheduling(){
        for (PCB pcb : scheduling) {
            System.out.print(pcb.getId()+"("+pcb.getCycleNum()+")"+" "+pcb.getProcessingTime()+" | ");
        }
        System.out.println(" ");
    }
}
