package dynamic.partition.management;

import java.util.ArrayList;

public class Kernel {
    Memory me = new Memory();
    int parId = 1;
    public void initialization(int size){
        me.setCapacity(size);
        me.getAvailablePartition().add(new Partition(parId,size,1));
        parId++;
    }
    public void firstOrBestOrWorstFit(Request req, int ins){
        ArrayList<Partition> abp = me.getAvailablePartition();

        if (abp.isEmpty()){
            System.out.println("当前内存已分配完！");
            return;
        }

        if (ins==1){
            abp.sort((o1, o2) -> o1.getStartingAddress() - o2.getStartingAddress());
        }else if (ins==2){
            abp.sort((o1, o2) -> o1.getSize() - o2.getSize());
        }else if (ins==3){
            abp.sort((o1, o2) -> o2.getSize() - o1.getSize());
            if (abp.get(0).getSize()<req.getPcbSize()){
                me.getRequest().add(req);
                System.out.println("内存资源不足，请求分配失败！");
                return;
            }
        }

        //记录是否分配成功
        boolean b = false;

        for (int i = 0; i < abp.size(); i++) {
            if (abp.get(i).getSize()>=req.getPcbSize()){
                me.getMemoryAllocation().add(new Partition((abp.get(i).getId()*10+req.getPcbId()),
                        req.getPcbSize(),abp.get(i).getStartingAddress()));
                System.out.println("请求分配成功!");
                b = true;
                if (abp.get(i).getSize()==req.getPcbSize()){
                    abp.remove(i);
                }else {
                    abp.get(i).reduceSize(req.getPcbSize());
                    abp.get(i).addStartingAddress(req.getPcbSize());
                }
                break;
            }
        }

        if (!b){
            me.getRequest().add(req);
            System.out.println("内存资源不足，请求分配失败！");
        }else if (!me.getRequest().isEmpty()){
            for (int i = 0; i < me.getRequest().size(); i++) {
                if (me.getRequest().get(i).equals(req)){
                    me.getRequest().remove(i);
                    break;
                }
            }
        }
    }
    public void recycling(int id){
        ArrayList<Partition> mac = me.getMemoryAllocation();
        ArrayList<Partition> abp = me.getAvailablePartition();
        if (mac.isEmpty()){
            System.out.println("当前无内存分配！");
            return;
        }
        for (int i = 0; i < mac.size(); i++) {
            if (mac.get(i).getId()==id){
                int id1 = mac.get(i).getId();
                abp.add(mac.remove(i));
                System.out.println("退回请求成功！");
                //合并分区
                abp.sort((o1, o2) -> o1.getStartingAddress() - o2.getStartingAddress());
                for (int j = 0; j < abp.size(); j++) {
                    if (abp.get(j).getId()==id1){
                        boolean b1 = abp.get(j-1).getStartingAddress()+abp.get(j-1).
                                getSize()==abp.get(j).getStartingAddress();
                        boolean b2 = j<abp.size()-1&&abp.get(j).getStartingAddress()+
                                abp.get(j).getSize()==abp.get(j+1).getStartingAddress();
                        if (b1&&b2){
                            abp.get(j-1).addSize(abp.get(j).getSize()+abp.get(j+1).getSize());
                            abp.remove(j);
                            abp.remove(j+1);
                            break;
                        }else if (b1){
                            abp.get(j-1).addSize(abp.get(j).getSize());
                            abp.remove(j);
                            break;
                        }else if (b2){
                            abp.get(j).addSize(abp.get(j+1).getSize());
                            abp.remove(j+1);
                            break;
                        }
                    }
                }
                break;
            }
            if (i==mac.size()-1){
                System.out.println("未找到该请求！");
            }
        }
    }

    public void viewMemoryAllocation(){
        me.getMemoryAllocation().sort((o1, o2) -> o1.getStartingAddress() - o2.getStartingAddress());
        for (Partition par : me.getMemoryAllocation()) {
            System.out.println("分区号："+par.getId()+"  分区大小："+par.getSize()+
                    "  分区开始地址："+par.getStartingAddress()+"  占用的进程号："+par.getPcbId());
        }
    }

}
